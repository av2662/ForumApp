package anna.appforum.controller;

import android.content.Intent;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import java.util.ArrayList;
import anna.appforum.MainActivity;
import anna.appforum.R;
import anna.appforum.RegisterActivity;
import anna.appforum.model.DBHandlerEmployee;
import anna.appforum.model.Employee;

public class RegisterController implements View.OnClickListener{

    private EditText userEmailEdt, userPasswordEdt;

    private EditText userUserNameEdt, userFirstNameEdt, userLastNameEdt;
    private DBHandlerEmployee dbHandlerEmployee;
    private RegisterActivity registerActivity;
    public RegisterController(RegisterActivity registerActivity){
        this.registerActivity = registerActivity;
    }

    @Override
    public void onClick(View view) {
        dbHandlerEmployee = new DBHandlerEmployee(registerActivity);
       if(view.getId() == R.id.homeButton) {
            Intent intent = new Intent(view.getContext(), MainActivity.class);
            view.getContext().startActivity(intent);
        }
         if(view.getId() == R.id.regButton){
            userEmailEdt = (EditText) registerActivity.findViewById(R.id.editEmailAddress);
            userPasswordEdt = (EditText) registerActivity.findViewById(R.id.editPassword);
            userFirstNameEdt = (EditText) registerActivity.findViewById(R.id.editFirstName);
            userLastNameEdt = (EditText) registerActivity.findViewById(R.id.editLastName);
            userUserNameEdt = (EditText) registerActivity.findViewById(R.id.editUserName);

            String userEmail = userEmailEdt.getText().toString();
            String userPassword = userPasswordEdt.getText().toString();
            String userUserName = userUserNameEdt.getText().toString();
            String userFirstName = userFirstNameEdt.getText().toString();
            String userLastName = userLastNameEdt.getText().toString();


            // validating if the text fields are empty or not.
            if (userEmail.isEmpty() || userPassword.isEmpty() || userUserName.isEmpty() || userFirstName.isEmpty() || userLastName.isEmpty() ) {
                Toast.makeText(registerActivity, "Please enter all the data..", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean value = checkUserName(userUserName);
            if(value){
                Toast.makeText(registerActivity, "User name is not available.", Toast.LENGTH_SHORT).show();
                return;
            }

            /* validate if password meets requirements */
            String numRegex = ".*[0-9].*";
            String upperLetterRegex = ".*[A-Z].*";
            String lowerLetterRegex = ".*[a-z].*";
            String specialRegex = ".*[!#$%?-].*";

            if (!userPassword.matches(numRegex) || !userPassword.matches(upperLetterRegex)
                || !userPassword.matches(lowerLetterRegex) || !userPassword.matches(specialRegex)){
                Toast.makeText(registerActivity, "Password does not meet requirements.", Toast.LENGTH_SHORT).show();
                return;

            }
            // on below line we are calling a method to add new
            // course to sqlite data and pass all our values to it.
            dbHandlerEmployee.addNewUser(userEmail, userPassword,userUserName, userFirstName, userLastName);

            // after adding the data we are displaying a toast message.
            Toast.makeText(registerActivity, "User has been added.", Toast.LENGTH_SHORT).show();
            userEmailEdt.setText("");
            userPasswordEdt.setText("");
            userUserNameEdt.setText("");
            userFirstNameEdt.setText("");
            userLastNameEdt.setText("");
        }
    }

    /* checks if user name is already taken */
    public boolean checkUserName(String userName){
        boolean value = false;
        ArrayList<Employee> employeeArrayList = dbHandlerEmployee.readEmployees();

        for(int i = 0; i < employeeArrayList.size(); i++){
            if(userName.equals(employeeArrayList.get(i).getUserName()))
                return true;
        }
        return value;
    }
}
