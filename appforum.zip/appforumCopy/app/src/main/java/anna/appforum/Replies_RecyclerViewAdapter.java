package anna.appforum;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import anna.appforum.controller.MainController;
import anna.appforum.model.DBHandlerEmployee;
import anna.appforum.model.Employee;
import anna.appforum.model.Replies;


public class Replies_RecyclerViewAdapter extends RecyclerView.Adapter<Replies_RecyclerViewAdapter.MyViewHolder>{

    Context context;
    ArrayList<Replies> repArrayList;


    public Replies_RecyclerViewAdapter(Context context, ArrayList<Replies> repArrayList){
        this.context = context;
        this.repArrayList =repArrayList;
    }

    @NonNull
    @Override
    public Replies_RecyclerViewAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.recyler_view_row_replies, parent,false);
        return new  Replies_RecyclerViewAdapter.MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Replies_RecyclerViewAdapter.MyViewHolder holder, int position) {
        ArrayList<Employee> employeeArrayList;
        DBHandlerEmployee dbHandlerEmployee;
        dbHandlerEmployee = new DBHandlerEmployee(context.getApplicationContext());
        employeeArrayList = dbHandlerEmployee.readEmployees();

        int userId = repArrayList.get(position).getUserID();
        String userName = "this is incorrect";

        for(int i = 0; i < employeeArrayList.size(); i++){
            if(employeeArrayList.get(i).getId() == userId){
                userName = employeeArrayList.get(i).getUserName();
            }
        }

        holder.tViewName.setText(userName);
        holder.tViewReply.setText(repArrayList.get(position).getReply());
    }

    @Override
    public int getItemCount() {
        return repArrayList.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder{

        TextView tViewName, tViewReply;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            tViewName = itemView.findViewById(R.id.textView14);
            tViewReply = itemView.findViewById(R.id.textView15);
        }
    }
}
