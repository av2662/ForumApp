package anna.appforum.controller;

import android.content.Intent;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import anna.appforum.AddDiscussionActivity;
import anna.appforum.DiscussionOptionsActivity;
import anna.appforum.R;
import anna.appforum.model.DBHandlerDiscussion;

public class AddDiscussionController implements View.OnClickListener{

    private int userID;
    private DBHandlerDiscussion dbHandlerDiscussion;
    private AddDiscussionActivity addDiscussionActivity;

    private EditText subjectNameEdt, subjectStarterEdt;

    public AddDiscussionController(int id, AddDiscussionActivity addDiscussionActivity){
        this.userID = id;
        this.addDiscussionActivity = addDiscussionActivity;
    }
    @Override
    public void onClick(View view) {
        if(view.getId() == R.id.discussionHomeButton){
            Intent intent = new Intent(view.getContext(), DiscussionOptionsActivity.class);
            intent.putExtra("userID", userID);
            view.getContext().startActivity(intent);
        }
        if(view.getId() == R.id.addButton){
            dbHandlerDiscussion = new DBHandlerDiscussion(addDiscussionActivity);
            subjectNameEdt = (EditText) addDiscussionActivity.findViewById(R.id.editSubjectName);
            subjectStarterEdt = (EditText) addDiscussionActivity.findViewById(R.id.editSubjectStarter);
            String subjectName = subjectNameEdt.getText().toString();
            String subjectStarter = subjectStarterEdt.getText().toString();

            if (subjectName.isEmpty() || subjectStarter.isEmpty()) {
                Toast.makeText(addDiscussionActivity, "Please enter all the data..", Toast.LENGTH_SHORT).show();
                return;
            }
            if(subjectStarter.length() > 180){
                Toast.makeText(addDiscussionActivity, "Character limit is 180.", Toast.LENGTH_SHORT).show();
                return;
            }

            dbHandlerDiscussion.addNewDiscussion(subjectName, subjectStarter, userID);
            Toast.makeText(addDiscussionActivity, "Discussion has been created", Toast.LENGTH_SHORT).show();
            subjectNameEdt.setText("");
            subjectStarterEdt.setText("");

        }
    }

}
