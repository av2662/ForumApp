package anna.appforum.controller;

import android.content.Intent;
import android.view.View;

import anna.appforum.DiscussionOptionsActivity;
import anna.appforum.PostReplyActivity;
import anna.appforum.R;

public class RepliesController implements View.OnClickListener{
    @Override
    public void onClick(View view) {

        DiscussionOptionsActivity discussionOptionsActivity = new DiscussionOptionsActivity();
        int userId = discussionOptionsActivity.getUser();

        if (view.getId() == R.id.backToDiscussionButton){
            Intent intent = new Intent(view.getContext(), DiscussionOptionsActivity.class);
            intent.putExtra("userID", userId);
            view.getContext().startActivity(intent);
        }
        else if(view.getId() == R.id.goToPostReplyButton){
            Intent intent = new Intent(view.getContext(), PostReplyActivity.class);
            intent.putExtra("userID", userId);
            view.getContext().startActivity(intent);
        }
    }
}
