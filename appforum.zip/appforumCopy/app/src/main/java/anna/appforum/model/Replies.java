package anna.appforum.model;

public class Replies {
    private int userID;
    private int discussionId;
    private String reply;

    public Replies(int userID, String reply, int discussionId){
        this.userID = userID;
        this.discussionId=discussionId;
        this.reply=reply;
    }

    public int getDiscussionId() {
        return discussionId;
    }

    public String getReply() {
        return reply;
    }

    public int getUserID() {
        return userID;
    }
}
