package anna.appforum;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import java.util.ArrayList;

import anna.appforum.controller.MainController;
import anna.appforum.controller.RepliesController;
import anna.appforum.model.DBHandlerReplies;
import anna.appforum.model.Discussions;
import anna.appforum.model.Employee;
import anna.appforum.model.Replies;

public class RepliesActivity extends AppCompatActivity {

    public static String discussionName;
    public ArrayList<Replies> repliesArrayList;
    private DBHandlerReplies dbHandlerReplies;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_replies);


        Bundle extras = getIntent().getExtras();
        int userID = extras.getInt("userID");
        discussionName = extras.getString("discussionName");

        TextView discussionNameView = (TextView) findViewById(R.id.repliesDiscussionName);
        TextView originalPostUserView = (TextView) findViewById(R.id.originalPostUser);
        TextView starterView = (TextView) findViewById(R.id.repliesOriginalStarter) ;

        discussionNameView.setText(discussionName);
        originalPostUserView.setText(getUserName(discussionName));
        starterView.setText(getDiscussionStarter(discussionName));



        ImageButton backButton = findViewById(R.id.backToDiscussionButton);
        Button addReplyButton = findViewById(R.id.goToPostReplyButton);

        backButton.setOnClickListener(new RepliesController());
        addReplyButton.setOnClickListener(new RepliesController());


        dbHandlerReplies = new DBHandlerReplies(RepliesActivity.this);
        repliesArrayList = dbHandlerReplies.readReplies(getDiscussionID(discussionName));


        RecyclerView recyclerView = findViewById(R.id.mRecylerViewReplies);
        Replies_RecyclerViewAdapter adapter = new Replies_RecyclerViewAdapter(this, repliesArrayList);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

    }
    public String getDiscussionName(){
        return discussionName;
    }

    private String getDiscussionStarter(String discussionName){

        DiscussionOptionsActivity discussionOptionsActivity = new DiscussionOptionsActivity();
        ArrayList<Discussions> discussionsArrayList;
        discussionsArrayList = discussionOptionsActivity.getDisArrayList();

        for(int i = 0; i < discussionsArrayList.size(); i++){
            if(discussionsArrayList.get(i).getSubjectName().equals(discussionName))
                return discussionsArrayList.get(i).getBasicStarter();
        }
        return "not correct";
    }
    private int getDiscussionID(String discussionName){
        DiscussionOptionsActivity discussionOptionsActivity = new DiscussionOptionsActivity();
        ArrayList<Discussions> discussionsArrayList;
        discussionsArrayList = discussionOptionsActivity.getDisArrayList();


        for(int i = 0; i < discussionsArrayList.size(); i++){
            if(discussionsArrayList.get(i).getSubjectName().equals(discussionName)){
                return discussionsArrayList.get(i).getDiscussionID();
            }
        }

        return 0;
    }

    private String getUserName(String discussionName){

        MainActivity mainActivity = new MainActivity();
        MainController mainController = new MainController(mainActivity);
        ArrayList<Employee> employeeArrayList = mainController.getEmployeeArrayList();


        DiscussionOptionsActivity discussionOptionsActivity = new DiscussionOptionsActivity();
        ArrayList<Discussions> discussionsArrayList;
        discussionsArrayList = discussionOptionsActivity.getDisArrayList();

        int original_user = 0;

        for(int i = 0; i < discussionsArrayList.size(); i++){
            if(discussionsArrayList.get(i).getSubjectName().equals(discussionName)){
                original_user = discussionsArrayList.get(i).getUserID();
                break;
            }
        }
        for(int i = 0; i < employeeArrayList.size(); i++){
            if(employeeArrayList.get(i).getId() == original_user)
                return employeeArrayList.get(i).getUserName();
        }
        return "not working";
    }
}