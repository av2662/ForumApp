package anna.appforum;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.res.AssetManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Scanner;

import anna.appforum.controller.DiscussionOptionsController;
import anna.appforum.model.DBHandlerDiscussion;
import anna.appforum.model.Discussions;

public class DiscussionOptionsActivity extends AppCompatActivity {

    public static int userID;
    public static ArrayList<Discussions> discussionsArrayList;
    private DBHandlerDiscussion dbHandlerDiscussion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_discussion_options);


        Bundle extras = getIntent().getExtras();
        userID = extras.getInt("userID");


        dbHandlerDiscussion = new DBHandlerDiscussion(DiscussionOptionsActivity.this);

        ImageButton addDiscussion = findViewById(R.id.addDiscussionButton);
        addDiscussion.setOnClickListener(new DiscussionOptionsController(userID));

        RecyclerView recyclerView = findViewById(R.id.mRecyclerView);
        discussionsArrayList = dbHandlerDiscussion.readDiscussions();

        DO_RecyclerViewAdapter adapter = new DO_RecyclerViewAdapter(this, discussionsArrayList);

        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

    }

    public static int getUser() {
        return userID;
    }

    public static ArrayList<Discussions> getDisArrayList(){
        return discussionsArrayList;
    }
}