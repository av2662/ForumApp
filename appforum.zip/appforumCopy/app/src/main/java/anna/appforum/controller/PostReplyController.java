package anna.appforum.controller;

import android.content.Intent;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import java.util.ArrayList;
import anna.appforum.DiscussionOptionsActivity;
import anna.appforum.PostReplyActivity;
import anna.appforum.R;
import anna.appforum.RepliesActivity;
import anna.appforum.model.DBHandlerReplies;
import anna.appforum.model.Discussions;

public class PostReplyController implements View.OnClickListener{

    private EditText replyEdt;
    private DBHandlerReplies dbHandlerReplies;
    private PostReplyActivity postReplyActivity;

    private int counter = 0;

    public PostReplyController(PostReplyActivity postReplyActivity){
        this.postReplyActivity = postReplyActivity;
    }


    @Override
    public void onClick(View view) {
        DiscussionOptionsActivity discussionOptionsActivity = new DiscussionOptionsActivity();
        int userID = discussionOptionsActivity.getUser();

        RepliesActivity repliesActivity = new RepliesActivity();
        String discussionName = repliesActivity.getDiscussionName();

        if (view.getId() == R.id.goBackToReplies){
            Intent intent = new Intent(view.getContext(), RepliesActivity.class);
            intent.putExtra("userID", userID);
            intent.putExtra("discussionName", discussionName);
            view.getContext().startActivity(intent);
        }
        if(view.getId() == R.id.postReplyButton){
            counter++;
            if(counter > 1){
                Toast.makeText(postReplyActivity, "Reply has been posted.", Toast.LENGTH_SHORT).show();
                return;
            }
            dbHandlerReplies = new DBHandlerReplies(postReplyActivity);
            replyEdt = (EditText) postReplyActivity.findViewById(R.id.editMultiLineReply);
            String reply = replyEdt.getText().toString();

            if (reply.isEmpty()) {
                Toast.makeText(postReplyActivity, "Please enter reply..", Toast.LENGTH_SHORT).show();
                return;
            }

            dbHandlerReplies.addNewReply(userID, reply, getDiscussionID(discussionName, discussionOptionsActivity));
            Toast.makeText(postReplyActivity, "Reply has been posted.", Toast.LENGTH_SHORT).show();

        }


    }
    private int getDiscussionID(String discussionName, DiscussionOptionsActivity discussionOptionsActivity){
        ArrayList<Discussions> discussionsArrayList;
        discussionsArrayList = discussionOptionsActivity.getDisArrayList();

        for(int i = 0; i < discussionsArrayList.size(); i++){
            if(discussionsArrayList.get(i).getSubjectName().equals(discussionName)){
                return discussionsArrayList.get(i).getDiscussionID();
            }
        }

        return 0;
    }
}
