package anna.appforum;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;

import anna.appforum.controller.RegisterController;
import anna.appforum.model.DBHandlerEmployee;

public class RegisterActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        Button homeButton = findViewById(R.id.homeButton);
        homeButton.setOnClickListener(new RegisterController(this));


        Button registerBut = findViewById(R.id.regButton);
        registerBut.setOnClickListener(new RegisterController(this));



    }
}