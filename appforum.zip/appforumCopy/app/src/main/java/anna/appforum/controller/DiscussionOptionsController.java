package anna.appforum.controller;

import android.content.Intent;
import android.view.View;

import anna.appforum.AddDiscussionActivity;

import anna.appforum.R;

public class DiscussionOptionsController implements View.OnClickListener{

    private int userID;

    public DiscussionOptionsController(int userID){
        this.userID = userID;
    }
    @Override
    public void onClick(View view) {
        if(view.getId() == R.id.addDiscussionButton){
            Intent intent = new Intent(view.getContext(), AddDiscussionActivity.class);
            intent.putExtra("userID", userID);
            view.getContext().startActivity(intent);
        }
    }
}
