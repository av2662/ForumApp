package anna.appforum.model;

public class Employee {
    private String email;
    private String password;

    private String userName; //make sure to loop through userNames to see if its taken already

    private String firstName;

    private String lastName;
    private int id;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public int getId() {
        return id;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getUserName() {
        return userName;
    }

    public Employee(int id, String email, String password, String userName, String firstName, String lastName){
        this.id = id;
        this.email = email;
        this.password = password;
        this.userName = userName;
        this.firstName = firstName;
        this.lastName = lastName;
    }
}
