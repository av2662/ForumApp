package anna.appforum.model;

import java.util.ArrayList;

public class Discussions {
    private String subjectName; //i.e. dogs
    private String basicStarter; //i.e. what breed is the best dog?
    private int discussionID;

    private int userID;
    private ArrayList<Replies> arrReplies;

    public Discussions(String subjectName, String basicStarter, int discussionId, int userID){
        this.subjectName=subjectName;
        this.basicStarter=basicStarter;
        this.discussionID=discussionId;
        this.userID = userID;
        this.arrReplies = new ArrayList<>();
    }

    public String getSubjectName() {
        return subjectName;
    }

    public String getBasicStarter() {
        return basicStarter;
    }

    public int getDiscussionID() {
        return discussionID;
    }

    public int getUserID() {
        return userID;
    }

    public ArrayList<Replies> getArrReplies() {
        return arrReplies;
    }
}
