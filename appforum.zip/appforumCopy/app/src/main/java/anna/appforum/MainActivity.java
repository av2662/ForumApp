package anna.appforum;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import anna.appforum.controller.MainController;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button register = findViewById(R.id.registerButton);
        register.setOnClickListener(new MainController(this));

        Button signIn = findViewById(R.id.signInButton);
        signIn.setOnClickListener(new MainController(this));


    }
}