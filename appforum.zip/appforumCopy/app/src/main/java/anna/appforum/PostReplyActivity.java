package anna.appforum;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageButton;

import anna.appforum.controller.PostReplyController;

public class PostReplyActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_reply);

        ImageButton backButton = findViewById(R.id.goBackToReplies);
        backButton.setOnClickListener(new PostReplyController(this));

        ImageButton postButton = findViewById(R.id.postReplyButton);
        postButton.setOnClickListener(new PostReplyController(this));
    }
}