package anna.appforum.controller;

import android.content.Intent;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

import anna.appforum.DiscussionOptionsActivity;
import anna.appforum.MainActivity;
import anna.appforum.R;
import anna.appforum.RegisterActivity;
import anna.appforum.model.DBHandlerEmployee;
import anna.appforum.model.Employee;

public class MainController implements View.OnClickListener{

    private EditText userEmailEdt, userPasswordEdt;
    public static ArrayList<Employee> employeeArrayList;
    private DBHandlerEmployee dbHandlerEmployee;
    private MainActivity mainActivity;
    public MainController(MainActivity mainActivity){
        this.mainActivity = mainActivity;
    }
    @Override
    public void onClick(View view) {

        userEmailEdt = mainActivity.findViewById(R.id.editTextTextEmailAddress);
        userPasswordEdt = mainActivity.findViewById(R.id.editTextTextPassword);

        if(view.getId() == R.id.signInButton){
            dbHandlerEmployee = new DBHandlerEmployee(view.getContext());

            String userEmail = userEmailEdt.getText().toString();
            String userPassword = userPasswordEdt.getText().toString();

            if (userEmail.isEmpty() || userPassword.isEmpty()) {
                Toast.makeText(view.getContext(), "Please enter all the data..", Toast.LENGTH_SHORT).show();
                return;
            }
            employeeArrayList = dbHandlerEmployee.readEmployees();
            int index = 0;
            boolean check = false;

            for(int i = 0; i < employeeArrayList.size(); i++){
                if(userEmail.equals(employeeArrayList.get(i).getEmail())) {
                    index = i;
                    check = true;
                    break;
                }
            }
            if(check == false){
                Toast.makeText(view.getContext(), "User is not registered", Toast.LENGTH_SHORT).show();
                return;
            }

            //System.out.println(userEmail + " " +employeeArrayList.get(index).getEmail() + employeeArrayList.get(index).getPassword());
            if(employeeArrayList.get(index).getPassword().equals(userPassword)){
                System.out.println("YOU DID IT " + userEmail);
                Intent intent = new Intent(view.getContext(), DiscussionOptionsActivity.class);
                intent.putExtra("userID", employeeArrayList.get(index).getId());
                //intent.putExtra("userEmail", userEmail);
                view.getContext().startActivity(intent);
            }
            else
                Toast.makeText(view.getContext(), "Incorrect password", Toast.LENGTH_SHORT).show();
        }

        if(view.getId() == R.id.registerButton){
            Intent intent = new Intent(view.getContext(), RegisterActivity.class);
            view.getContext().startActivity(intent);
        }

    }

    public ArrayList<Employee> getEmployeeArrayList() {
        return employeeArrayList;
    }
}

