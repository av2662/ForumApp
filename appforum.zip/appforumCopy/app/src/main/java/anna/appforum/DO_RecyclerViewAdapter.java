package anna.appforum;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import anna.appforum.model.Discussions;

public class DO_RecyclerViewAdapter extends RecyclerView.Adapter<DO_RecyclerViewAdapter.MyViewHolder> {

    Context context;
    ArrayList<Discussions> discussionsArrayList;



    public DO_RecyclerViewAdapter(Context context, ArrayList<Discussions> discussionsArrayList){
        this.context = context;
        this.discussionsArrayList =discussionsArrayList;
    }

    @NonNull
    @Override
    public DO_RecyclerViewAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.recycler_view_row_do, parent,false);
        return new  DO_RecyclerViewAdapter.MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DO_RecyclerViewAdapter.MyViewHolder holder, int position) {
        holder.tViewName.setText(discussionsArrayList.get(position).getSubjectName());
        holder.tViewStarter.setText(discussionsArrayList.get(position).getBasicStarter());
        //holder.itemView.setTag(discussionsArrayList.get(position).getSubjectName());
        //holder.addReplyButton.setTag(discussionsArrayList.get(position).getSubjectName());
        holder.addReplyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DiscussionOptionsActivity discussionOptionsActivity = new DiscussionOptionsActivity();
                //discussionOptionsActivity.getUser();
                Intent intent = new Intent(view.getContext(), RepliesActivity.class);
                intent.putExtra("userID", discussionOptionsActivity.getUser());
                intent.putExtra("discussionName", discussionsArrayList.get(holder.getAdapterPosition()).getSubjectName());
                view.getContext().startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return discussionsArrayList.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder{

        TextView tViewName, tViewStarter;
        ImageButton addReplyButton;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            tViewName = itemView.findViewById(R.id.topicNameView);
            tViewStarter = itemView.findViewById(R.id.topicStarterView);
            addReplyButton = itemView.findViewById(R.id.imageButton2);

        }
    }


}
