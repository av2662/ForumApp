package anna.appforum.model;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class DBHandlerReplies extends SQLiteOpenHelper {
    private static final String DB_NAME = "repliesdb";

    // below int is our database version
    private static final int DB_VERSION = 1;

    // below variable is for our table name.
    private static final String TABLE_NAME = "Replies";

    // below variable is for our id column.
    private static final String REPLY_ID_COL = "rep_id";

    private static final String DISCUSSION_ID_COL = "dis_id";

    public static final String USER_ID_COL = "user_id";
    private static final String REPLY_STR_COL = "ReplyStr";

    public DBHandlerReplies(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    // below method is for creating a database by running a sqlite query
    @Override
    public void onCreate(SQLiteDatabase db) {
        // on below line we are creating
        // an sqlite query and we are
        // setting our column names
        // along with their data types.
        String query = "CREATE TABLE " + TABLE_NAME + " ("
                + REPLY_ID_COL + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + USER_ID_COL + " INTEGER,"
                + REPLY_STR_COL + " TEXT,"
                + DISCUSSION_ID_COL  + " INTEGER)";

        // at last we are calling a exec sql
        // method to execute above sql query
        db.execSQL(query);
    }

    // this method is use to add new course to our sqlite database.
    public void addNewReply(int userID, String replyStr, int discussionID) {

        // on below line we are creating a variable for
        // our sqlite database and calling writable method
        // as we are writing data in our database.
        SQLiteDatabase db = this.getWritableDatabase();

        // on below line we are creating a
        // variable for content values.
        ContentValues values = new ContentValues();

        // on below line we are passing all values
        // along with its key and value pair.
        values.put(USER_ID_COL, userID);
        values.put(REPLY_STR_COL, replyStr);
        values.put(DISCUSSION_ID_COL, discussionID);

        db.insert(TABLE_NAME, null, values);

        // at last we are closing our
        // database after adding database.
        db.close();
    }


    // we have created a new method for reading all the courses.
    public ArrayList<Replies> readReplies(int id)
    {

        // on below line we are creating a
        // database for reading our database.
        SQLiteDatabase db = this.getReadableDatabase();

        // on below line we are creating a cursor with query to
        // read data from database.
/*        Cursor cursorReplies
                = db.rawQuery("SELECT * FROM " + TABLE_NAME + "WHERE " + DISCUSSION_ID_COL + " = " + id, null);
*/
        /*
        Cursor cursorDiscussions
                = db.rawQuery("SELECT * FROM " + TABLE_NAME, null);
        */

        Cursor cursorReplies
                = db.rawQuery("SELECT * FROM REPLIES WHERE dis_id = " + id, null);
        // on below line we are creating a new array list.
        ArrayList<Replies> repliesArrayList
                = new ArrayList<>();

        // moving our cursor to first position.
        if (cursorReplies.moveToFirst()) {
            do {
                // on below line we are adding the data from
                // cursor to our array list.
                repliesArrayList.add(new Replies(
                        cursorReplies.getInt(1),
                        cursorReplies.getString(2),
                        cursorReplies.getInt(3)));
            } while (cursorReplies.moveToNext());
            // moving our cursor to next.
        }


        // at last closing our cursor
        // and returning our array list.
        cursorReplies.close();
        return repliesArrayList;
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // this method is called to check if the table exists already.
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }
}


