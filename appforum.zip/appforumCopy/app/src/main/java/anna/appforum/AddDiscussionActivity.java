package anna.appforum;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;
import anna.appforum.controller.AddDiscussionController;

public class AddDiscussionActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_discussion);

        Bundle extras = getIntent().getExtras();
        int userID = extras.getInt("userID");


        ImageButton discussionHome = findViewById(R.id.discussionHomeButton);
        discussionHome.setOnClickListener(new AddDiscussionController(userID, this));

        Button addButton = findViewById(R.id.addButton);
        addButton.setOnClickListener(new AddDiscussionController(userID,this));




    }
}